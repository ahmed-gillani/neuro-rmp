// // src/components/patients/PatientDetailView.tsx
// import { ArrowLeft } from 'lucide-react';
// import PatientHeader from './PatientHeader';
// import PatientTabs from './PatientTabs';
// import type { Patient } from '../../types';

// // Import all tabs directly (recommended in React + TypeScript)
// import OverviewTab from './tabs/OverviewTab';
// import ReadingsTab from './tabs/ReadingsTab';
// import MonitoringTab from './tabs/MonitoringTab';
// import AlertsTab from './tabs/AlertsTab';
// import NotesTab from './tabs/NotesTab';
// import DevicesTab from './tabs/DevicesTab';
// import BillingTab from './tabs/BillingTab';
// import DocumentsTab from './tabs/DocumentsTab';

// interface PatientDetailViewProps {
//   patient: Patient;
//   activeTab: string;
//   setActiveTab: (tab: string) => void;
//   onBack: () => void;
// }

// export default function PatientDetailView({
//   patient,
//   activeTab,
//   setActiveTab,
//   onBack,
// }: PatientDetailViewProps) {

//   // Tab mapping
//   const tabComponents: Record<string, React.ComponentType<any>> = {
//     overview: OverviewTab,
//     readings: ReadingsTab,
//     monitoring: MonitoringTab,
//     alerts: AlertsTab,
//     notes: NotesTab,
//     devices: DevicesTab,
//     billing: BillingTab,
//     documents: DocumentsTab,
//   };

//   const ActiveTabComponent = tabComponents[activeTab] || OverviewTab;

//   return (
//     <div className="min-h-screen bg-slate-50">
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
//         {/* Back Button */}
//         <button
//           onClick={onBack}
//           className="flex items-center gap-3 mb-8 text-slate-600 hover:text-teal-600 transition-colors group font-medium"
//         >
//           <div className="w-9 h-9 rounded-2xl border flex items-center justify-center group-hover:border-teal-200 transition-all">
//             <ArrowLeft className="w-5 h-5" />
//           </div>
//           <span className="text-lg">Back to All Patients</span>
//         </button>

//         {/* Main Patient Container */}
//         <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-100">
          
//           {/* Premium Patient Header */}
//           <PatientHeader patient={patient} />

//           {/* Modern Tabs */}
//           <div className="sticky top-0 bg-white z-30 border-b border-slate-100">
//             <PatientTabs 
//               activeTab={activeTab} 
//               setActiveTab={setActiveTab} 
//             />
//           </div>

//           {/* Content Area */}
//           <div className="p-8 lg:p-12 bg-slate-50">
//             <div className="max-w-5xl mx-auto">
//               <ActiveTabComponent patient={patient} />
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }













// import { ArrowLeft, Phone, Mail, Calendar, User } from 'lucide-react';
// import type { Patient } from '../../types';
// import Button from '../common/Button';
// import Badge from '../common/Badge';

// interface PatientDetailViewProps {
//   patient: Patient;
//   activeTab: 'overview' | 'history' | 'careplan' | 'documents';
//   setActiveTab: (tab: 'overview' | 'history' | 'careplan' | 'documents') => void;
//   onBack: () => void;
// }

// export default function PatientDetailView({
//   patient,
//   activeTab,
//   setActiveTab,
//   onBack,
// }: PatientDetailViewProps) {
//   return (
//     <div className="min-h-screen bg-slate-50">
//       {/* Top Navigation Bar */}
//       <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
//           <div className="flex items-center gap-4">
//             <Button
//               variant="ghost"
//               onClick={onBack}
//               className="flex items-center gap-2 text-slate-600 hover:text-slate-900"
//             >
//               <ArrowLeft className="w-5 h-5" />
//               Back to Patients
//             </Button>
//             <div className="h-6 w-px bg-slate-200" />
//             <div>
//               <h1 className="text-2xl font-bold text-slate-900">{patient.name}</h1>
//               <p className="text-sm text-slate-500">ID: {patient.id}</p>
//             </div>
//           </div>

//           <div className="flex items-center gap-3">
//             <Button variant="outline" className="flex items-center gap-2">
//               <Phone className="w-4 h-4" /> Call
//             </Button>
//             <Button variant="outline" className="flex items-center gap-2">
//               <Mail className="w-4 h-4" /> Message
//             </Button>
//             <Button className="bg-teal-600 hover:bg-teal-700">
//               <Calendar className="w-4 h-4 mr-2" /> Schedule Visit
//             </Button>
//           </div>
//         </div>

//         {/* Tabs */}
//         <div className="max-w-7xl mx-auto px-4 sm:px-6">
//           <div className="flex border-b border-slate-200">
//             {(['overview', 'history', 'careplan', 'documents'] as const).map((tab) => (
//               <button
//                 key={tab}
//                 onClick={() => setActiveTab(tab)}
//                 className={`px-8 py-4 text-sm font-medium capitalize transition-all border-b-2 -mb-px
//                   ${activeTab === tab
//                     ? 'border-teal-600 text-teal-700'
//                     : 'border-transparent text-slate-500 hover:text-slate-700'
//                   }`}
//               >
//                 {tab}
//               </button>
//             ))}
//           </div>
//         </div>
//       </div>

//       <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
//         {/* Patient Header Info */}
//         <div className="bg-white rounded-3xl p-6 mb-8 shadow-sm flex flex-col md:flex-row gap-6 items-start">
//           <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-teal-500 to-indigo-600 flex items-center justify-center text-white text-4xl font-bold flex-shrink-0">
//             {patient.name.split(' ').map(n => n[0]).join('')}
//           </div>

//           <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
//             <div>
//               <p className="text-xs text-slate-500">Phone</p>
//               <p className="font-medium text-lg">{patient.phone}</p>
//             </div>
//             <div>
//               <p className="text-xs text-slate-500">Primary Provider</p>
//               <p className="font-medium">{patient.primaryProvider}</p>
//             </div>
//             <div>
//               <p className="text-xs text-slate-500">Enrolled Since</p>
//               <p className="font-medium">{patient.enrollmentDate}</p>
//             </div>
//             <div>
//               <p className="text-xs text-slate-500">Status</p>
//               <Badge status={patient.status} />
//             </div>
//           </div>
//         </div>

//         {/* Tab Content */}
//         <div className="bg-white rounded-3xl shadow-sm p-8">
//           {activeTab === 'overview' && (
//             <div className="space-y-8">
//               <h3 className="text-xl font-semibold">Overview</h3>
//               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
//                 <div>
//                   <h4 className="font-medium mb-3 text-slate-700">Personal Information</h4>
//                   {/* Add more fields as per your Patient type */}
//                 </div>
//                 <div>
//                   <h4 className="font-medium mb-3 text-slate-700">Recent Activity</h4>
//                   <p className="text-slate-500">Last visit: 12 days ago</p>
//                 </div>
//               </div>
//             </div>
//           )}

//           {activeTab === 'history' && (
//             <div>
//               <h3 className="text-xl font-semibold mb-6">Medical History</h3>
//               <p className="text-slate-500">Medical history content will go here...</p>
//             </div>
//           )}

//           {activeTab === 'careplan' && (
//             <div>
//               <h3 className="text-xl font-semibold mb-6">Care Plan</h3>
//               <p className="text-slate-500">Care plan & medications content here...</p>
//             </div>
//           )}

//           {activeTab === 'documents' && (
//             <div>
//               <h3 className="text-xl font-semibold mb-6">Documents & Reports</h3>
//               <p className="text-slate-500">Documents section coming soon...</p>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// }













// src/components/patients/PatientDetailView.tsx
import { ArrowLeft } from 'lucide-react';
import PatientHeader from './PatientHeader';
import PatientTabs from './PatientTabs';
import type { Patient } from '../../types';
 
import OverviewTab from './tabs/OverviewTab';
import ReadingsTab from './tabs/ReadingsTab';
import MonitoringTab from './tabs/MonitoringTab';
import AlertsTab from './tabs/AlertsTab';
import NotesTab from './tabs/NotesTab';
import DevicesTab from './tabs/DevicesTab';
import BillingTab from './tabs/BillingTab';
import DocumentsTab from './tabs/DocumentsTab';
 
interface PatientDetailViewProps {
  patient: Patient;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onBack: () => void;
}
 
export default function PatientDetailView({
  patient,
  activeTab,
  setActiveTab,
  onBack,
}: PatientDetailViewProps) {
  const tabComponents: Record<string, React.ComponentType<any>> = {
    overview: OverviewTab, readings: ReadingsTab, monitoring: MonitoringTab,
    alerts: AlertsTab, notes: NotesTab, devices: DevicesTab,
    billing: BillingTab, documents: DocumentsTab,
  };
 
  const ActiveTabComponent = tabComponents[activeTab] || OverviewTab;
 
  return (
    <div className="min-h-screen bg-slate-100">
      <div className="max-w-7xl mx-auto px-3 sm:px-5 lg:px-8 py-3 md:py-5">
 
        {/* Back Button */}
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 mb-3 text-slate-600 hover:text-teal-600 font-medium text-sm transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Patients</span>
        </button>
 
        <div className="bg-white rounded-2xl shadow-md overflow-hidden border border-slate-200">
          <PatientHeader patient={patient} />
          <PatientTabs activeTab={activeTab} setActiveTab={setActiveTab} />
 
          {/* Tab Content */}
          <div className="p-4 sm:p-5 md:p-6 bg-slate-50">
            <div className="max-w-5xl mx-auto">
              <ActiveTabComponent patient={patient} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}