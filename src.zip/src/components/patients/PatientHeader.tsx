// // src/components/patients/PatientHeader.tsx
// import Badge from '../common/Badge';
// import type { Patient } from '../../types';

// interface PatientHeaderProps {
//   patient: Patient;
// }

// export default function PatientHeader({ patient }: PatientHeaderProps) {
//   return (
//     <div className="patient-hero px-6 sm:px-10 py-8 sm:py-12 bg-gradient-to-r from-slate-800 to-slate-900 text-white rounded-t-3xl">
//       <div className="flex flex-col lg:flex-row gap-6 lg:items-center">

//         {/* Large Avatar */}
//         <div className="w-24 h-24 lg:w-32 lg:h-32 rounded-2xl bg-white/10 flex items-center justify-center hero-avatar-text font-bold border-2 border-white/30 shadow-lg flex-shrink-0">
//           {patient.name.split(' ').map(n => n[0]).join('')}
//         </div>

//         {/* Patient Info */}
//         <div className="flex-1">
//           <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
//             <div>
//               <h1 className="hero-title font-bold tracking-tight text-white text-2xl sm:text-3xl md:text-4xl">
//                 {patient.name}
//               </h1>
//               <p className="text-slate-200 text-lg sm:text-xl mt-2">{patient.phone}</p>
//             </div>

//             <Badge
//               status={patient.status}
//               className="text-base px-6 py-2 text-lg font-semibold bg-white/6"
//             />
//           </div>

//           <div className="mt-6 sm:mt-8 grid grid-cols-1 sm:grid-cols-3 gap-6 text-slate-200">
//             <div>
//               <p className="text-sm opacity-80">Primary Provider</p>
//               <p className="font-semibold text-lg mt-1 text-white">Dr. {patient.primaryProvider}</p>
//             </div>

//             <div>
//               <p className="text-sm opacity-80">Enrolled On</p>
//               <p className="font-semibold text-lg mt-1 text-white">
//                 {new Date(patient.enrollmentDate).toLocaleDateString('en-US', {
//                   month: 'long',
//                   year: 'numeric'
//                 })}
//               </p>
//             </div>

//             {patient.dob && (
//               <div>
//                 <p className="text-sm opacity-80">Date of Birth</p>
//                 <p className="font-semibold text-lg mt-1 text-white">{patient.dob}</p>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }






// src/components/patients/PatientHeader.tsx
import type { Patient } from '../../types';
import Badge from '../common/Badge';

export default function PatientHeader({ patient }: { patient: Patient }) {
  return (
    <div className="px-5 sm:px-7 pt-5 pb-5 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      <div className="flex items-center gap-4">

        {/* Avatar */}
        <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-xl bg-gradient-to-br from-teal-400 to-indigo-500
                        flex items-center justify-center text-xl sm:text-2xl font-bold flex-shrink-0">
          {patient.name.split(' ').map(n => n[0]).join('')}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-xl sm:text-2xl font-bold leading-tight text-white">{patient.name}</h1>
            <Badge status={patient.status} />
          </div>
          <p className="text-slate-400 text-xs mt-0.5">ID: {patient.id}</p>

          {/* Info row */}
          <div className="mt-3 flex flex-wrap gap-x-6 gap-y-2 text-xs">
            <div>
              <span className="text-slate-400">Phone: </span>
              <span className="font-medium text-slate-200">{patient.phone}</span>
            </div>
            <div>
              <span className="text-slate-400">Provider: </span>
              <span className="font-medium text-slate-200">{patient.primaryProvider}</span>
            </div>
            <div>
              <span className="text-slate-400">Enrolled: </span>
              <span className="font-medium text-slate-200">{patient.enrollmentDate}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}