// src/components/patients/tabs/AlertsTab.tsx
import Card from '../../common/Card';
import Badge from '../../common/Badge';
import Button from '../../common/Button';
import { AlertTriangle, Phone, CheckCircle } from 'lucide-react';
import { useReadingsStore } from '../../../stores/useReadingsStore';

export default function AlertsTab() {
  const { oorReadings, markAsReviewed } = useReadingsStore();

  const patientAlerts = oorReadings; // In real app, filter by selected patient

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold">Active Alerts</h3>
        <Badge variant="error" className="text-sm px-4 py-1">
          {patientAlerts.length} Critical
        </Badge>
      </div>

      {patientAlerts.length === 0 ? (
        <Card className="p-12 text-center bg-green-50 border-green-100">
          <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
          <p className="text-lg font-medium text-green-700">No Active Alerts</p>
          <p className="text-gray-500 mt-1">All readings are within normal range.</p>
        </Card>
      ) : (
        <div className="space-y-4">
          {patientAlerts.map((alert) => (
            <Card key={alert.id} className="border-l-4 border-l-red-500 bg-red-50/50">
              <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="text-red-500" />
                    <p className="font-semibold text-red-700">{alert.type} Out of Range</p>
                  </div>
                  <p className="text-3xl font-bold text-red-600 mt-1">{alert.value}</p>
                  <p className="text-sm text-gray-600 mt-1">
                    {new Date(alert.timestamp).toLocaleString()}
                  </p>
                  {alert.notes && <p className="text-gray-600 mt-2">{alert.notes}</p>}
                </div>

                <div className="flex flex-col gap-3 w-full md:w-auto">
                  <Button 
                    onClick={() => markAsReviewed(alert.id)}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Mark as Reviewed
                  </Button>
                  <Button variant="outline">
                    <Phone className="w-4 h-4 mr-2" />
                    Call Patient
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Quick Stats */}
      <Card>
        <div className="grid grid-cols-2 gap-6 text-center">
          <div>
            <p className="text-4xl font-black text-red-600">{patientAlerts.length}</p>
            <p className="text-xs uppercase tracking-widest text-gray-500">OOR Readings</p>
          </div>
          <div>
            <p className="text-4xl font-black text-amber-600">2</p>
            <p className="text-xs uppercase tracking-widest text-gray-500">Missed Readings</p>
          </div>
        </div>
      </Card>
    </div>
  );
}