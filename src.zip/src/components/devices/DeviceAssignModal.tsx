// src/components/devices/DeviceAssignModal.tsx
import { useState } from 'react';
import Modal from '../common/Modal';
import Button from '../common/Button';
import type { Patient } from '../../types';

interface DeviceAssignModalProps {
  isOpen: boolean;
  onClose: () => void;
  deviceId: string;
  onAssign: (deviceId: string, patientId: string) => void;
  patients: Patient[];
}

export default function DeviceAssignModal({
  isOpen,
  onClose,
  deviceId,
  onAssign,
  patients,
}: DeviceAssignModalProps) {
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');

  const handleAssign = () => {
    if (selectedPatientId) {
      onAssign(deviceId, selectedPatientId);
      setSelectedPatientId('');
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Assign Device to Patient">
      <div className="space-y-6 py-2">
        <div>
          <label className="block text-sm font-medium mb-3">Select Patient</label>
          <select
            className="w-full p-4 border border-gray-300 rounded-2xl text-gray-900 focus:border-blue-500 outline-none"
            value={selectedPatientId}
            onChange={(e) => setSelectedPatientId(e.target.value)}
          >
            <option value="">-- Choose Patient --</option>
            {patients.map((patient) => (
              <option key={patient.id} value={patient.id}>
                {patient.name} — {patient.primaryProvider}
              </option>
            ))}
          </select>
        </div>

        <div className="flex gap-3 pt-6">
          <Button variant="outline" className="flex-1" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            className="flex-1" 
            onClick={handleAssign}
            disabled={!selectedPatientId}
          >
            Assign Device
          </Button>
        </div>
      </div>
    </Modal>
  );
}