    // src/components/readings/ManualReadingModal.tsx
import { useState } from 'react';
import Modal from '../common/Modal';
import Button from '../common/Button';
import { useReadingsStore } from '../../stores/useReadingsStore';
import { usePatientsStore } from '../../stores/usePatientsStore';
import type { Reading } from '../../types';

interface ManualReadingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const readingTypes = [
  { label: 'Blood Pressure', value: 'Blood Pressure', unit: 'mmHg' },
  { label: 'Glucose', value: 'Glucose', unit: 'mg/dL' },
  { label: 'SpO2', value: 'SpO2', unit: '%' },
  { label: 'Weight', value: 'Weight', unit: 'kg' },
  { label: 'Heart Rate', value: 'Heart Rate', unit: 'bpm' },
];

export default function ManualReadingModal({ isOpen, onClose }: ManualReadingModalProps) {
  const { addReading } = useReadingsStore();
  const { patients } = usePatientsStore();

  const [formData, setFormData] = useState({
    patientId: '',
    type: 'Blood Pressure',
    value: '',
    notes: '',
    timestamp: new Date().toISOString().slice(0, 16),
  });

  const selectedType = readingTypes.find(t => t.value === formData.type);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.patientId || !formData.value) return;

    const newReading: Reading = {
      id: `rd_${Date.now()}`,
      patientId: formData.patientId,
      type: formData.type as any,
      value: formData.value,
      unit: selectedType?.unit || '',
      timestamp: formData.timestamp,
      isOOR: Math.random() > 0.6,
      notes: formData.notes || undefined,
    };

    addReading(newReading);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Add Manual Reading">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">Patient</label>
          <select
            required
            className="w-full p-4 border border-gray-300 rounded-2xl"
            value={formData.patientId}
            onChange={(e) => setFormData({ ...formData, patientId: e.target.value })}
          >
            <option value="">Select Patient</option>
            {patients.map(p => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Reading Type</label>
          <select
            className="w-full p-4 border border-gray-300 rounded-2xl"
            value={formData.type}
            onChange={(e) => setFormData({ ...formData, type: e.target.value })}
          >
            {readingTypes.map(t => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Value</label>
            <input
              type="text"
              required
              className="w-full p-4 border border-gray-300 rounded-2xl font-mono"
              placeholder="148/92 or 195"
              value={formData.value}
              onChange={(e) => setFormData({ ...formData, value: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-2">Unit</label>
            <input 
              className="w-full p-4 border border-gray-300 rounded-2xl bg-gray-50" 
              value={selectedType?.unit || ''} 
              disabled 
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Date & Time</label>
          <input
            type="datetime-local"
            className="w-full p-4 border border-gray-300 rounded-2xl"
            value={formData.timestamp}
            onChange={(e) => setFormData({ ...formData, timestamp: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Notes</label>
          <textarea
            className="w-full p-4 border border-gray-300 rounded-2xl min-h-[90px]"
            placeholder="Patient feeling dizzy after reading..."
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          />
        </div>

        <div className="flex gap-3 pt-4">
          <Button type="button" variant="outline" className="flex-1" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" className="flex-1">Save Reading</Button>
        </div>
      </form>
    </Modal>
  );
}