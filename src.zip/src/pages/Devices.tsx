import { useState } from 'react';
import { useDevicesStore } from '../stores/useDevicesStore';
import { usePatientsStore } from '../stores/usePatientsStore';
import Card from '../components/common/Card';
import Button from '../components/common/Button';
import Badge from '../components/common/Badge';
import DeviceAssignModal from '../components/devices/DeviceAssignModal';
import { Plus, Search, Filter } from 'lucide-react';

export default function Devices() {
  const { devices, assignDevice, updateDeviceStatus } = useDevicesStore();
  const { patients } = usePatientsStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Available' | 'Assigned' | 'In Repair'>('All');
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [selectedDevice, setSelectedDevice] = useState<string | null>(null);

  const filteredDevices = devices.filter((dev) => {
    const matchesSearch = dev.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         dev.serialNumber.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || dev.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleAssign = (deviceId: string, patientId: string) => {
    assignDevice(deviceId, patientId);
    setIsAssignModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Device Management</h1>
          <p className="text-gray-500">Inventory • Assignment • Status Tracking</p>
        </div>
        <Button onClick={() => {/* Add new device modal */}}>
          <Plus className="w-5 h-5 mr-2" /> Add New Device
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-3.5 text-gray-400" />
            <input
              type="text"
              placeholder="Search devices or serial number..."
              className="w-full pl-11 py-3 border border-gray-200 rounded-2xl"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <select
            className="px-5 py-3 border border-gray-200 rounded-2xl"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
          >
            <option value="All">All Status</option>
            <option value="Available">Available</option>
            <option value="Assigned">Assigned</option>
            <option value="In Repair">In Repair</option>
          </select>
        </div>
      </Card>

      {/* Devices Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDevices.map((device) => {
          const assignedPatient = patients.find(p => p.id === device.patientId);
          
          return (
            <Card key={device.id} className="hover:shadow-xl transition-all">
              <div className="flex justify-between">
                <div>
                  <p className="font-bold text-lg">{device.type}</p>
                  <p className="text-sm text-gray-500 font-mono">{device.serialNumber}</p>
                </div>
                <Badge 
                  variant={device.status === 'Assigned' ? 'success' : 
                          device.status === 'In Repair' ? 'error' : 'info'}
                >
                  {device.status}
                </Badge>
              </div>

              {assignedPatient && (
                <div className="mt-4 p-3 bg-gray-50 rounded-xl">
                  <p className="text-sm">Assigned to:</p>
                  <p className="font-semibold">{assignedPatient.name}</p>
                </div>
              )}

              <div className="flex gap-3 mt-6">
                {device.status === 'Available' && (
                  <Button 
                    onClick={() => { setSelectedDevice(device.id); setIsAssignModalOpen(true); }}
                    className="flex-1"
                  >
                    Assign to Patient
                  </Button>
                )}
                {device.status === 'Assigned' && (
                  <Button 
                    variant="outline"
                    onClick={() => updateDeviceStatus(device.id, 'Available')}
                    className="flex-1"
                  >
                    Return Device
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      <DeviceAssignModal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        deviceId={selectedDevice!}
        onAssign={handleAssign}
        patients={patients}
      />
    </div>
  );
}